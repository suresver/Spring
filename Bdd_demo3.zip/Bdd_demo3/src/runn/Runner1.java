package runn;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(features={"S:\\Eclipsenew-workspace\\Bdd_demo3\\featurefiles\\reg.Feature"},
glue="StepDefinition",
plugin = {"pretty", "html:target/suresh-report"},
monochrome=true,
dryRun=false	)
public class Runner1 {

}
