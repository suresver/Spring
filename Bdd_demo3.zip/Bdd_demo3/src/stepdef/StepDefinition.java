package stepdef;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefinition {

	WebDriver d;
	@Given("^Open ksrtc web site$")
	public void open_ksrtc_web_site() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		System.setProperty("webdriver.chrome.driver", "C:\\chromedriver_win32\\chromedriver.exe");
		 d=new ChromeDriver();
	        d.get("http://www.ksrtc.in/oprs-web/");
	        d.manage().window().maximize();
	}

	@When("^user enters \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\"$")
	public void user_enters_and_and(String emailid, String name, String mob) throws Throwable {
		
		d.findElement(By.linkText("New User Register")).click();

  		//Thread.sleep(2000);
  		d.findElement(By.xpath("//*[@id='email']")).sendKeys(emailid);
  		d.findElement(By.xpath("//*[@id='fullName']")).sendKeys(name);
  		d.findElement(By.xpath("//*[@id='mobileNo']")).sendKeys(mob);
        //a=a*a*2;
  		d.findElement(By.xpath("//*[@id='SaveBtn']")).click();
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
	}

	@Then("^Login should be successfull$")
	public void login_should_be_successfull() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
	}


	}


